#ifndef _COMMON_H
#define _COMMON_H

#include "mat_base.h"

#include <stdbool.h>
#include <stdio.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/times.h> 
/** Name of well-known requests FIFO in server-dir used by both clients
 *  and server.
 */
#define REQUESTS_FIFO "REQUESTS"

#define CLIENT_REQUEST_FIFO "CLI_REQUEST"

#define CLIENT_RESPONSE_FIFO "CLI_RESPONSE"

/* add declarations common to both server and client */
#define MAX_BUF 1024

typedef struct {
    pid_t pid;
    int modulePathLen;
    char *modulePath;
    char *serverDir;
} Data;

typedef struct {
    int n1;
    int n2;
    int n3;
    int *a;
    int *b;
} Request;

typedef struct {
    int n1;
    int n3;
    int *c;
    long walltime;
    long utime;
    long stime;
} Response;
#endif //ifndef _COMMON_H

#include "common.h"
#include "matmul.h"

#include "errors.h"

//#define DO_TRACE 1
#include "trace.h"
#include <assert.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>

/** Return an interface to the client end of a client-server matrix
 *  multiplier set up to multiply using multiplication module
 *  specified by modulePath with server daemon running in directory
 *  serverDir.
 *
 *  If modulePath is relative, then it must be found on the server's
 *  LD_LIBRARY_PATH interpreted relative to serverDir.  The name of
 *  the multiplication function in the loaded module is the last
 *  component of the modulePath with the extension (if any) removed.
 *
 *  If trace is non-NULL, then turn on tracing for all subsequent
 *  calls to mulMatrixMul() which use the returned MatrixMul.
 *  Specifically, after completing each matrix multiplication, the
 *  client should log a single line on trace in the format:
 *
 *  utime: UTIME, stime: STIME, wall: WALL
 *
 *  where UTIME, STIME and WALL gives the amount of user time, system
 *  time and wall time in times() clock ticks needed within the server
 *  to perform only the multiplication function provided by the
 *  module. The spacing must be exactly as shown above and all the
 *  clock tick values must be output in decimal with no leading zeros
 *  or redundant + signs.
 *
 *  Set *err to an appropriate error number (documented in errno(3))
 *  on error.
 *
 *  This call should result in the creation of a new worker process on
 *  the server, spawned using the double-fork technique.  The worker
 *  process must load and link the specified module.  All future
 *  multiplication requests on the returned MatrixMul must be
 *  performed using the specified module within this worker process.
 *  All IPC between the client and server processes must be performed
 *  using only named pipes (FIFO's).
 */
struct MatrixMul {
    pid_t pid;
    int fdReq;
    int fdRes;
    int modulePathLen;
    char *modulePath;
    char *serverDir;
};

MatrixMul * newMatrixMul(const char *serverDir, const char *modulePath, FILE *trace, int *err)
{
    /**
     * Create object of the structure
     */
    Data clientData;

    /**
     * Create object of the MatrixMul, set fields same as clientData and
     * return the pointer to the client.
     */
    MatrixMul *matrixMulImpl = (MatrixMul *) malloc(sizeof(MatrixMul));

    /**
     * 1. Get pid of the client process 
     */
    clientData.pid = getpid();
    matrixMulImpl->pid = clientData.pid;
    //printf("Pid generated at client side = %d\n", clientData.pid);
    //printf("Pid stored in matrixMulImpl at client side  = %d\n", matrixMulImpl->pid);

    char *tmp = (char *)serverDir;

    /**
     * tmp will contain the final path to the REQUESTS_FIFO
     */
    char *sDir = NULL;
    char *fifoDir1 = NULL;
    char *fifoDir2 = NULL;

    asprintf(&sDir, "%s%s%s", (char*)tmp, "/", REQUESTS_FIFO);

    int fd;
    ssize_t writeCount;

    /* Open the REQUESTS_FIFO*/
    fd = open(sDir, O_WRONLY);

    if(fd < 0)
    {
        printf("FIFO open error at client side!\n");
        //return (MatrixMul *)-1;
    }

    /**
     * 2. Set modulePath into the structure oject
     */
    clientData.modulePath = (char *)modulePath;
    matrixMulImpl->modulePath = clientData.modulePath;
    //printf("Complete module path ==> %s\n", clientData.modulePath);

    /**
     * 3. Get module path length and set to structure object.
     */
    size_t mpLen = strlen(modulePath);
    clientData.modulePathLen = mpLen + 1;
    matrixMulImpl->modulePathLen = clientData.modulePathLen;
    //printf("Length of Module Path = %d\n", clientData.modulePathLen);

    clientData.serverDir = sDir;
    matrixMulImpl->serverDir = clientData.serverDir;


    /* Write pid to the common FIFO */
    writeCount = write(fd, &clientData, sizeof(Data));
    if(writeCount < 0)
    {
        printf("REQUESTS_FIFO pid write error at client\n");
    }

    /**
     * reset writeCount to 0 and reuse again for writing modulePath
     */
    writeCount = 0;


    /* Write modulePath to the common FIFO */
    writeCount = write(fd, clientData.modulePath, sizeof(char) * mpLen + 1);
    if(writeCount < 0)
    {
        fprintf(stderr, "REQUESTS_FIFO modulePathLengths write error at client!\n");
    }



    asprintf(&fifoDir1, "%s%s%s", (char*)serverDir, "/", CLIENT_REQUEST_FIFO);
    asprintf(&fifoDir2, "%s%s%s", (char*)serverDir, "/", CLIENT_RESPONSE_FIFO);

    /**
     * Create fifo at client side for sending request to the server
     */
    mkfifo(fifoDir1, 0666);
    mkfifo(fifoDir2, 0666);

    /**
     * Open the fifo with O_WRONLY flag to write the data over FIFO
     */
    matrixMulImpl->fdReq = open(fifoDir1, O_WRONLY);
    if(matrixMulImpl->fdReq < 0)
    {
        printf("\nCLIENT_REQUEST_FIFO opening error!\n");
    }
    /**
     * Create fifo at client side for receiving response from the server
     */
    matrixMulImpl->fdRes = open(fifoDir2, O_RDONLY);
    if(matrixMulImpl->fdRes < 0)
    {
        printf("\nCLIENT_RESPONSE_FIFO opening error!\n");
    }

    return matrixMulImpl; //NULL;
}

/** Free all resources used by matMul.  Specifically, free all memory
 *  used by matMul, remove all FIFO's created specifically for matMul
 *  and set up the worker process on the server to terminate.  Set
 *  *err appropriately (as documented in errno(3)) on error.
 */
void freeMatrixMul(MatrixMul *matMul, int *err)
{
}

/** Set matrix c[n1][n3] to a[n1][n2] * b[n2][n3].  It is assumed that
 *  the caller has allocated c[][] appropriately.  Set *err to an
 *  appropriate error number (documented in errno(3)) on error.  If
 *  *err is returned as non-zero, then the matMul object may no longer
 *  be valid and future calls to mulMatrixMul() may have unpredictable
 *  behavior.  It is the responsibility of the caller to call
 *  freeMatrixMul() after an error.
 *
 *  The multiplication must be entirely on the server using the
 *  specified module by the worker process which was spawned when
 *  matMul was created.  Note that a single matMul instance may be
 *  used for performing multiple multiplications.  All IPC must be
 *  handled using FIFOs.
 */
void mulMatrixMul(const MatrixMul *matMul, int n1, int n2, int n3,
        CONST MatrixBaseType a[n1][n2],
        CONST MatrixBaseType b[n2][n3],
        MatrixBaseType c[n1][n3], int *err)
{
    /**
     * Set data of matrix A into "Request" structure object.
     */

    Request request;
    request.n1 = n1;
    request.n2 = n2;
    request.n3 = n3;

    /*
       printf("n1 = %d\n", n1);
       printf("n2 = %d\n", n2);
       printf("n3 = %d\n", n3);
       */

    /**
     * Create object of Response structure & set the fields of the structure
     */
    Response response;
    response.n1 = n1;
    response.n3 = n3;

    /**
     * Send the request structure to the daemon with following write call
     */
    int writeCount = 0;
    writeCount = write(matMul->fdReq, &request, sizeof(request));
    if(writeCount < 0)
    {
        printf("Error : Writing request at mulMatrixMul function!\n");
    }

    /**
     * Allocate memory for matrix A & B
     */
    request.a = malloc(n1 * n2 * sizeof(int)); 
    request.b = malloc(n2 * n3 * sizeof(int));

    /**
     * Setting matrix A data into the request structure
     */
    int i, j = 0;
    for(i = 0; i < n1; i++)
    {
        for(j = 0; j < n2; j++)
        {
            *(request.a + i*n2 + j) = a[i][j];
        }
    }

    /**
     * Print matrixA at client side
     */
    i = 0;  
    j = 0;
    //printf("\nPrinting Matrix A : \n");
    for(i = 0; i < n1; i++)
    {
        for(j = 0; j < n2; j++)
        {
        //    printf("%d\t", *(request.a + i*n2 + j)); //= a[i][j];
        }
        //printf("\n");
    }

    /**
     * Setting matrix B data into the request structure
     */
    i = 0; 
    j = 0;
    for(i = 0; i < n2; i++)
    {
        for(j = 0; j < n3; j++)
        {
            *(request.b + i*n3 + j) = b[i][j];
        }
    }

    /**
     * Print matrixB at client side
     */
    i = 0; 
    j = 0;
    //printf("\nPriting Matrix B : \n");
    for(i = 0; i < n2; i++)
    {
        for(j = 0; j < n3; j++)
        {
           // printf("%d\t", *(request.b + i*n2 + j)); //= a[i][j];*/
        }
        //printf("\n");
    }

    /**
     * Writing matrix A onto the CLIENT_REQUEST_FIFO
     */
    writeCount = 0;
    writeCount = write(matMul->fdReq, request.a, sizeof(int) * n1 * n2);
    if(writeCount < 0)
    {
        printf("Error : Writing matrixA to the request at mulMatrixMul!\n");
    }

    /**
     * Writing matrix B onto the CLIENT_REQUEST_FIFO
     */
    writeCount = 0;
    writeCount = write(matMul->fdReq, request.b, sizeof(int) * n2 * n3);
    if(writeCount < 0)
    {
        printf("Error : Writing matrixB to the request at mulMatrixMul!\n");
    }

    /**
     * Read matrix C received from Server.
     */
    int readCount = 0;


    /**
     * Print matrixC at client side
     *
     i = 0; j = 0;
     printf("\nPriting Matrix C : \n");
     for(i = 0; i < n1; i++)
     {
     for(j = 0; j < n3; j++)
     {
     printf("%d\t", *(response.c + i*n3 + j)); //= a[i][j];
     }
     printf("\n");
     }*/

    readCount = 0;
    readCount = read(matMul->fdRes, &response, (sizeof(Response)));
    printf("utime: %ld, stime: %ld, wall: %ld\n", response.utime, response.stime, response.walltime);   

    response.c = malloc(sizeof(int) * n1 * n3);
    readCount = read(matMul->fdRes, response.c, sizeof(int) * n1 * n3);
    if(readCount < 0)
    {
        printf("Error : Reading MatrixC from response at mulMatrixMul!\n");
    }
    /** 
     * Setting the values of matrix C
     */
    for(i = 0; i < n1; i++)
    {
        for(j = 0; j < n3; j++)
        {
            c[i][j] = *(response.c + i*n3 + j); // = b[i][j];
        }
    }



}

#include "common.h"
#include "mat_base.h"

//#define DO_TRACE 1
//#include <trace.h>
//#include <errors.h>
#include <assert.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <sys/times.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <syslog.h>
#include <string.h>
#include <errno.h>
#include <dlfcn.h>

void *getMulFn(const char *modulePath, void **dlHandleP, const char *fnName, int *err)
{
    void *dlHandle = (*dlHandleP) ? *dlHandleP : dlopen(modulePath, RTLD_NOW);
    printf("\nInside getMulFn\n");
    if(!dlHandle)
    {
        *err = ELIBACC;
        return NULL;
    }
    *dlHandleP = dlHandle;
    void *fn = dlsym(dlHandle, fnName);
    printf("\ngetMulFn successful!\n");
    return fn;
}

void doWorkerService(int fd, Data serverData)
{

    /**
     * matrixMulFn Load specified module dynamically (dlopen()) and return multiplication function (dlsym())
     */
    int err = 0;
    void *dlHandle = NULL;
    char *fnName = NULL;

    if(strrchr(serverData.modulePath, '/') != NULL)
    {
        char *first = rindex(serverData.modulePath, '/');
        ++first;
        char *second = strtok(first, ".");
        int length = strlen(second + 1);
        fnName = malloc(length);
        strcpy(fnName, second);
        printf("Module name got = %s\n", fnName);
    }
    else
    {
        char *tmp = NULL;
        int length = strlen(serverData.modulePath) + 1;
        tmp = malloc(serverData.modulePathLen);
        strcpy(tmp, serverData.modulePath);


        char *second = strtok(tmp, ".");
        length = strlen(second);
        fnName = malloc(length);
        strcpy(fnName, second); 
        printf("Module Name got = %s\n", fnName);

    }

    MatrixMulFn *matrixMul = getMulFn(serverData.modulePath, &dlHandle, fnName, &err); 
    if(err)
    {
        printf("Cannot find %s in %s \n", "naive_matmul", serverData.modulePath);
    }

    int fdReq;
    int fdRes;

    /**
     * Open the client fifo with respective flags.
     */
    fdReq = open(CLIENT_REQUEST_FIFO, O_RDONLY);
    if(fdReq < 0)
    {
        printf("Error in opening CLIENT_REQUEST_FIFO at server side!\n");
    }

    /**
     * Open the client response fifo with respective flags
     */
    fdRes = open(CLIENT_RESPONSE_FIFO, O_WRONLY);
    if(fdRes < 0) 
    {
        printf("Error in opening CLIENT_RESPONSE_FIFO at server side!\n");
    }

    while(1)
    {
        /**
         * Create object of Request & Response structure and 
         * receive & send data from client & to client respectively
         */
        Request request;
        Response response;

        int readCount = 0;
        readCount = read(fdReq, &request, sizeof(Request));
        if(readCount < 0)
        {
            printf("\nError in reading request at server side!\n");
        }
        /**
         * Get all the dimensions
         */
        int n1 = request.n1;
        int n2 = request.n2;
        int n3 = request.n3;

        /**
         * Allocate the memory for matrixA and receive it from read call
         */
        request.a = malloc(sizeof(int) * n1 * n2);
        readCount = 0; 
        readCount = read(fdReq, request.a, sizeof(int) * n1 * n2); 

        /*
        printf("\nServer : printing Matrix A\n");
        for(i = 0; i < n1; i++)
        {
            for(j = 0; j < n2; j++)
            {
                printf("%d\t", *(request.a + i*n2 + j));
            }
            printf("\n");
        }
        */

        /**
         * Allocate the memory for matrixB and receive it from read call
         */
        request.b = malloc(sizeof(int) * n2 * n3);
        readCount = 0; 
        readCount = read(fdReq, request.b, sizeof(int) * n2 * n3); 

        /*
        printf("\nServer : printing Matrix B\n");
        for(i = 0; i < n2; i++)
        {
            for(j = 0; j < n3; j++)
            {
                printf("%d\t", *(request.b + i*n3 + j));
            }
            printf("\n");
        } 
        */

        /**
         * Set fields of the response structure
         */
        response.n1 = n1;
        response.n3 = n3;
        response.c = (int *) malloc(sizeof(int) * n1 * n3);
        int error = 0;

        struct tms start, end;

        clock_t startTime;
        clock_t endTime;

        if ((startTime = times(&start)) < 0) 
        {
            printf("cannot get start time\n");
        }
        
        matrixMul(n1, n2, n3, (MatrixBaseType (*)[n1])request.a,  (MatrixBaseType (*)[n3])request.b,  (MatrixBaseType (*)[n3]) response.c, &error);

        if ((endTime = times(&end)) < 0)
        {
             printf("cannot get start time \n");
        }
        
        response.walltime = endTime - startTime;
        response.utime = end.tms_utime - start.tms_utime;
        response.stime = end.tms_stime - start.tms_stime;
        /**
         * Write response.c back to the client
         */
        int writeCount = 0;

        /*
        printf("\nServer : printing Matrix C\n");
        for(i = 0; i < n1; i++)
        {
            for(j = 0; j < n3; j++)
            {
                printf("%d\t", *(response.c + i*n3 + j));
            }
            printf("\n");
        }
        */
        writeCount = 0;
        writeCount = write(fdRes, &response, sizeof(Response));
        if(writeCount < 0)
        {
            //printf("\nServer : Error in writing times \ n");
        }
        writeCount = write(fdRes, response.c, sizeof(int) * n1 * n3);
        if(writeCount < 0)
        {
            printf("\nServer : Error in writing Matrix C\n");
        }
        


    }
}


/** Called by the daemon service routine. Returns after using the double-fork technique 
 * to create a new worker process which runs some worker service routine. */
void makeWorker(int fd, Data serverData)
{
    printf("file descriptor received from doDaemonService = %d\n", fd);
    pid_t pid;

    if((pid = fork()) < 0)
        printf("Forking error!\n");
    else if(pid == 0)
    {
        if((pid = fork()) < 0)
            printf("Forking error!\n");
        else if(pid > 0)
            exit(0);
        /* Call to doWorkerService() */
        doWorkerService(fd, serverData);
        printf("Second child having pid = %d, parent pid = %d\n", getpid(), getppid());
        exit(0);
    }
    /* wait for first child */
    if(waitpid(pid, NULL, 0) != pid)
        printf("waitpid error!\n");
    /* Original Process */
}


/** Daemon service routine. Sit in an infinite loop waiting for
 *  connection request from clients. When one comes in simply
 *  creates a worker process to service the client.*/
void doDaemonService()
{
    int fd;
    ssize_t readCount;

    Data serverData;

    /* Create the named pipe : REQUESTS_FIFO that is known to 
     * Server as well as client */
    mkfifo(REQUESTS_FIFO, 0666);

    /* Open the common FIFO */
    fd = open(REQUESTS_FIFO, O_RDONLY);
    if(fd < 0)
    {
        printf("FIFO open error at deamon!\n");
    }

    /* It will not stop until atleast one request from client is available with the daemon. */
    while(1)
    {
        /* Read the message sent by client in the FIFO --> Pid is sent by client */
        readCount = read(fd, &serverData, sizeof(Data));
        if(readCount < 0)
        {
            printf("REQUESTS_FIFO serverData read error at daemon side!\n");
        }

        int mpLen = serverData.modulePathLen;
        serverData.modulePath = malloc(mpLen * sizeof(char));

        readCount = 0;
        readCount = read(fd, serverData.modulePath, mpLen);
        if(readCount < 0)
        {
            printf("REQUESTS_FIFO serverData.modulePath read error at daemon side!\n");
        }
        fprintf(stdout, "module path length received at server side = %d\n", mpLen);
        fprintf(stdout, "Pid received from client at server side = %d\n", serverData.pid);
        fprintf(stdout, "module path received at server side = %s\n", serverData.modulePath);
        printf(" Making call to makeWorker with fd =  %d...\n", fd);
        makeWorker(fd, serverData);   
        //break;
    }
}

static pid_t makeServer(const char *serverDir)
{
    pid_t pid, sid;

    /*Fork off the parent process*/
    if((pid = fork()) < 0)
    {
        printf("Forking Error!\n");
        return -1;
    }
    else if(pid != 0)
    {
        /*Parent*/
        return pid;
    }
    else
    {
        /* Child becomes the daemon*/
        /* Create a new sid for child process*/
        sid = setsid();

        /* If sid fails, log the failure*/
        if(sid < 0)
        {
            printf("Sid Error!\n");
            return -1;
        }

        /*Change the current working directory*/
        if((chdir(serverDir)) < 0)
        {
            printf("Changing Directory Error!\n");
            return -1;
        }

        /* Change the file mode mask*/
        umask(0);

        /* Close the standard file descriptors since daemon can not use the
         * terminal so it is a good idea to close them. Otherwise they are 
         * redundant and potential security hazards. */
        close(STDIN_FILENO);
        close(STDOUT_FILENO);
        close(STDERR_FILENO);

        /* Daemon service routine. Sit in an infinite loop waiting for
         * connection request from clients. When one comes in simply
         * creates a worker process to service the client.*/
        doDaemonService();

        /*Should never exit*/
        assert(0);

    }

    return 1234; //replace suitably
}

int main(int argc, const char *argv[])
{
    if (argc != 2) 
        fprintf(stderr, "usage: %s <server-dir>", argv[0]);
    const char *serverDir = argv[1];
    pid_t pid = makeServer(serverDir);
    printf("%ld\n", (long)pid);
    return 0;
}

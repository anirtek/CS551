#include "common.h"

//#define DO_TRACE 1
#include "trace.h"

/* implement definitions common to both server and client */

